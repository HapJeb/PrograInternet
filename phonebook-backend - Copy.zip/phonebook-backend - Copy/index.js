require('dotenv').config()
const express = require('express')
const morgan = require('morgan')
const cors = require('cors')
const mongoose = require('mongoose')

const app = express()

// Middlewares
app.use(cors())
app.use(express.json())
app.use(express.static('dist'))

// Morgan para ver peticiones HTTP en consola
morgan.token('body', (req) => JSON.stringify(req.body))
app.use(morgan(':method :url :status :res[content-length] - :response-time ms :body'))

// Conexión a MongoDB Atlas
const url = process.env.MONGODB_URI
console.log('Conectando a MongoDB...')

mongoose.set('strictQuery', false)
mongoose.connect(url)
  .then(() => {
    console.log('¡Conectado exitosamente a MongoDB!')
  })
  .catch(error => {
    console.log('Error al conectar a la base de datos:', error.message)
  })

// Esquema de Mongoose con validaciones
const personSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'El nombre es obligatorio'],
    minlength: [3, 'El nombre debe tener al menos 3 caracteres']
  },
  number: {
    type: String,
    required: [true, 'El número telefónico es obligatorio'],
    minlength: [8, 'El número debe tener al menos 8 dígitos'],
    validate: {
      validator: function(v) {
        return /^\d{2,3}-\d{5,}$/.test(v)
      },
      props: (props) => `${props.value} no es un número de teléfono válido. Formato requerido: XX-XXXXXXX`,
    }
  }
})

personSchema.set('toJSON', {
  transform: (document, returnedObject) => {
    returnedObject.id = returnedObject._id.toString()
    delete returnedObject._id
    delete returnedObject.__v
  }
})

const Person = mongoose.model('Person', personSchema)

// --- RUTAS DE LA API ---

app.get('/api/persons', (req, res) => {
  Person.find({}).then(persons => {
    res.json(persons)
  })
})

app.get('/api/persons/:id', (req, res, next) => {
  Person.findById(req.params.id)
    .then(person => {
      if (person) {
        res.json(person)
      } else {
        res.status(404).end()
      }
    })
    .catch(error => next(error))
})

app.post('/api/persons', (req, res, next) => {
  const { name, number } = req.body

  const person = new Person({ name, number })

  person.save()
    .then(savedPerson => {
      res.json(savedPerson)
    })
    .catch(error => next(error))
})

app.delete('/api/persons/:id', (req, res, next) => {
  Person.findByIdAndDelete(req.params.id)
    .then(() => {
      res.status(204).end()
    })
    .catch(error => next(error))
})

// --- MANEJADORES DE ERRORES ---
const unknownEndpoint = (request, response) => {
  response.status(404).send({ error: 'Ruta desconocida' })
}
app.use(unknownEndpoint)

const errorHandler = (error, request, response, next) => {
  console.error(error.message)

  if (error.name === 'CastError') {
    return response.status(400).send({ error: 'ID malformado' })
  } else if (error.name === 'ValidationError') {
    return response.status(400).json({ error: error.message })
  }

  next(error)
}
app.use(errorHandler)

// Puerto dinámico
const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`)
})